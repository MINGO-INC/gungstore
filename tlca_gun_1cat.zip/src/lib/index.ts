/**
 * TLCA Gun Register - Core Types and Constants
 * © 2026 TLCA Inventory Systems
 */

export const ROUTE_PATHS = {
  HOME: '/',
  ORDER_HISTORY: '/history',
  EMPLOYEE: '/employee/:slug',
};

export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Long Arms' | 'Side Arms' | 'Ammo & Accessories' | 'Specials';
  description?: string;
}

export interface Employee {
  id: string;
  name: string;
  slug: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  unitPrice: number;
  quantity: number;
  discountedPrice: number;
  totalPrice: number;
  commission: number;
}

export interface Order {
  id: string;
  employeeId: string;
  employeeName: string;
  customerType: string;
  items: OrderItem[];
  totalAmount: number;
  totalCommission: number;
  ledgerAmount: number;
  timestamp: string;
}

export const EMPLOYEES: Employee[] = [
  { id: 'emp_1', name: 'Cat', slug: 'cat' },
  { id: 'emp_2', name: 'Tom', slug: 'tom' },
  { id: 'emp_3', name: 'Rob', slug: 'rob' },
];

export const PRODUCTS: Product[] = [
  // Long Arms
  { id: 'la_1', name: 'Winchester Model 1873', price: 1250.00, category: 'Long Arms', description: "The Gun that Won the West." },
  { id: 'la_2', name: 'Sharps Buffalo Rifle', price: 1850.00, category: 'Long Arms', description: "Long-range precision instrument." },
  { id: 'la_3', name: 'Spencer Repeating Carbine', price: 950.00, category: 'Long Arms', description: "Seven-shot civil war veteran." },
  
  // Side Arms
  { id: 'sa_1', name: 'Colt Single Action Army', price: 850.00, category: 'Side Arms', description: "The Peacemaker, .45 caliber." },
  { id: 'sa_2', name: 'Smith & Wesson Model 3', price: 780.00, category: 'Side Arms', description: "Top-break Schofield variant." },
  { id: 'sa_3', name: 'Remington New Model Army', price: 650.00, category: 'Side Arms', description: "Solid frame percussion revolver." },
  
  // Ammo & Accessories
  { id: 'aa_1', name: '.45 Colt Ammo (Box of 50)', price: 45.00, category: 'Ammo & Accessories' },
  { id: 'aa_2', name: 'Hand-Tooled Leather Holster', price: 120.00, category: 'Ammo & Accessories' },
  { id: 'aa_3', name: 'Gun Oil & Cleaning Kit', price: 35.00, category: 'Ammo & Accessories' },
  { id: 'aa_4', name: 'Stetson Rough Rider Hat', price: 185.00, category: 'Ammo & Accessories' },
];

export const SPECIALS: Product[] = [
  { id: 'sp_1', name: 'Engraved Ivory Grip Colt', price: 4500.00, category: 'Specials', description: "Museum quality presentation piece." },
  { id: 'sp_2', name: 'Gold Inlaid Henry Rifle', price: 7200.00, category: 'Specials', description: "Numbered 1 of 100 commemorative." },
];

export const CUSTOMER_TYPES = {
  STANDARD: {
    id: 'standard',
    label: 'Standard Customer',
    discount: 0,
  },
  LAW_DOC: {
    id: 'law_doc',
    label: 'Law & Doc (10%)',
    discount: 0.10,
  },
  EMPLOYEE: {
    id: 'employee',
    label: 'Employee (20%)',
    discount: 0.20,
  },
} as const;

// Business Logic Constants
export const COMMISSION_RATE = 0.25; // 25% employee commission
export const LEDGER_RATE = 0.75;     // 75% to ledger
