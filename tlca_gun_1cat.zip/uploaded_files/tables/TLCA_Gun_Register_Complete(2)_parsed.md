# TLCA_Gun_Register_Complete(2) parsed content

**Note**: Excel parsing may be incomplete; use the original file for complete analysis

## Sheet: MAIN

|  |
|
|  | LONG ARMS |  |  |  |  | SIDE ARMS |  |  |  |  | AMMO & ACCESSORIES |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | Volcanic |  | $35.00 | $0.00 |  | Gun Oil |  | $0.50 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Semi-Automatic |  | $35.00 | $0.00 |  | Pistol Ammo |  | $3.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | Mauser |  | $35.00 | $0.00 |  | Rifle Ammo |  | $3.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Colt 1911 |  | $450.00 | $0.00 |  | Shotgun Shells |  | $3.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |  | P08 Luger |  | $350.00 | $0.00 |  | Engraved Plate |  | $20.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |  | Cattleman |  | $5.00 | $0.00 |  | Arrows |  | $2.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |  | Schofield |  | $15.00 | $0.00 |  | Tranquilizer |  | $75.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |  | Navy |  | $35.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |  | Lemat |  | $35.00 | $0.00 |  | SPECIALS |
|  | Carbine |  | $55.00 | $0.00 |  | Double Action |  | $45.00 | $0.00 |  | ITEM | QTY | PRICE | TOTAL |
|  | Bolt Action |  | $75.00 | $0.00 |  | Model 1875 |  | $330.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |  | Gambler's |  | $370.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |  | Webley |  | $370.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |  | Walker |  | $450.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  |
|  |
|  | Law & Doc 10% BLUE, Employee 20% Yellow |
|  |
|  |  |  |  |  |  | Total Sale: | $0.00 |
|  |  |  |  |  |  | Into Ledger: | $0.00 |
|  |  |  |  |  |  | Commission you keep: | $0.00 |

## Sheet: Cat

|  | Cat |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Tom

|  | Tom |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Rob

|  | Rob |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Morris

|  | Morris |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Employee 5

|  | Employee 5 |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Employee 6

|  | Employee 6 |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |

## Sheet: Employee 7

|  | Employee 7 |
| --- | --- |
|  | Items |  |  |  |  | SPECIALS |  |  |  | Customer Type |
|  | ITEM | QTY | PRICE | TOTAL |  | ITEM | QTY | PRICE | TOTAL |
|  | Pump |  | $75.00 | $0.00 |  | 2 Cattlemen & Springfield |  | $75.00 | $0.00 |
|  | Doublebarrel |  | $45.00 | $0.00 |  | Repeating Shotgun & 2 Schofield |  | $90.00 | $0.00 |
|  | Sawedoff |  | $35.00 | $0.00 |  | 2 Revolvers & Semi-Auto Shotgun |  | $110.00 | $0.00 |
|  | Semiauto |  | $55.00 | $0.00 |  | Evans Repeater & 2 Schofield |  | $50.00 | $0.00 |
|  | Repeating |  | $70.00 | $0.00 |
|  | Coach Gun |  | $300.00 | $0.00 |
|  | Evans |  | $25.00 | $0.00 |
|  | Winchester |  | $55.00 | $0.00 |
|  | Henry |  | $370.00 | $0.00 |
|  | Carbine |  | $55.00 | $0.00 |
|  | Bolt Action |  | $75.00 | $0.00 |
|  | Springfield |  | $70.00 | $0.00 |
|  | Mare's Leg |  | $350.00 | $0.00 |
|  | Gewehr 98 |  | $400.00 | $0.00 |
|  | Lee-Enfield MKIII |  | $400.00 | $0.00 |
|  | Martini-Henry |  | $350.00 | $0.00 |
|  | Mosin-Nagant M1891 |  | $400.00 | $0.00 |
|  | Battered Sharps 1863 |  | $350.00 | $0.00 |
|  | Rolling Block |  | $1,000.00 | $0.00 |
|  | Carcano |  | $1,000.00 | $0.00 |
|  | Exotic Double |  | $400.00 | $0.00 |
|  | Elephant Rifle |  | $500.00 | $0.00 |
|  | Volcanic |  | $35.00 | $0.00 |
|  | Semi-Automatic |  | $35.00 | $0.00 |
|  | Mauser |  | $35.00 | $0.00 |
|  | Colt 1911 |  | $450.00 | $0.00 |
|  | P08 Luger |  | $350.00 | $0.00 |
|  | Cattleman |  | $5.00 | $0.00 |
|  | Schofield |  | $15.00 | $0.00 |
|  | Navy |  | $35.00 | $0.00 |
|  | Lemat |  | $35.00 | $0.00 |
|  | Double Action |  | $45.00 | $0.00 |
|  | Model 1875 |  | $330.00 | $0.00 |
|  | Gambler's |  | $370.00 | $0.00 |
|  | Webley |  | $370.00 | $0.00 |
|  | Walker |  | $450.00 | $0.00 |
|  |  |
|  |  |
|  | Discounts: Law & Doc 10% \| Employee 20% |
|  |  |
|  | Total (Before Discount): |  | $0.00 |
|  | FINAL TOTAL: |  | $0.00 |
|  |  |
|  | Into Ledger (75%): |  | $0.00 |
|  | Your Commission (25%): |  | $0.00 |